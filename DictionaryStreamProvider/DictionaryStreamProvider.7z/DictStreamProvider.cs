﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using Orleans.Providers.Streams.Common;

namespace StellaStreams
{
    public class DictStreamProvider : PersistentStreamProvider<DictQueueAdapterFactory>
    {

    }
}
